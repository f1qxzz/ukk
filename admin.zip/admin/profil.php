<?php
require_once '../config/database.php';
require_once '../includes/session.php';
requireAdmin();

$conn = getConnection();
$msg     = '';
$msgType = '';
$id      = getPenggunaId();

// Ambil data user
$stmt = $conn->prepare("SELECT * FROM pengguna WHERE id_pengguna=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Ambil data user untuk header
$userStmt = $conn->prepare("SELECT foto, nama_pengguna FROM pengguna WHERE id_pengguna = ?");
$userStmt->bind_param("i", $id);
$userStmt->execute();
$userData = $userStmt->get_result()->fetch_assoc();
$userStmt->close();

// Inisial untuk avatar header
$initialsHeader = '';
foreach (explode(' ', trim($userData['nama_pengguna'] ?? getPenggunaName())) as $w) {
    $initialsHeader .= strtoupper(mb_substr($w, 0, 1));
    if (strlen($initialsHeader) >= 2) break;
}
$fotoPathHeader = (!empty($userData['foto']) && file_exists('../' . $userData['foto'])) 
            ? '../' . htmlspecialchars($userData['foto']) 
            : null;

/* ================= UPLOAD FOTO ================= */
if (isset($_POST['upload_foto'])) {
    $adaFile = isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE;

    if (!$adaFile) {
        $msg = 'Pilih file foto terlebih dahulu.';
        $msgType = 'danger';
    } elseif ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        $msg = 'Upload gagal, coba lagi.';
        $msgType = 'danger';
    } else {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        $ftype = mime_content_type($_FILES['foto']['tmp_name']);
        $fsize = $_FILES['foto']['size'];

        if (!in_array($ftype, $allowedTypes)) {
            $msg = 'Format tidak didukung. Gunakan JPG, PNG, atau WebP.';
            $msgType = 'danger';
        } elseif ($fsize > 2 * 1024 * 1024) {
            $msg = 'Ukuran file melebihi 2 MB.';
            $msgType = 'danger';
        } else {
            $ext     = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$ftype];
            $newName = 'foto_' . $id . '_' . time() . '.' . $ext;
            $dest    = '../uploads/foto_profil/' . $newName;

            if (!is_dir('../uploads/foto_profil/')) {
                mkdir('../uploads/foto_profil/', 0755, true);
            }

            if (move_uploaded_file($_FILES['foto']['tmp_name'], $dest)) {
                // Hapus foto lama jika ada
                if (!empty($user['foto']) && file_exists('../' . $user['foto'])) {
                    unlink('../' . $user['foto']);
                }

                $s = $conn->prepare("UPDATE pengguna SET foto=? WHERE id_pengguna=?");
                $fotoPath = 'uploads/foto_profil/' . $newName;
                $s->bind_param("si", $fotoPath, $id);
                if ($s->execute()) {
                    $user['foto'] = $fotoPath;
                    $msg = 'Foto profil berhasil diperbarui!';
                    $msgType = 'success';
                } else {
                    unlink($dest);
                    $msg = 'Gagal menyimpan foto ke database.';
                    $msgType = 'danger';
                }
                $s->close();
            } else {
                $msg = 'Gagal memindahkan file foto.';
                $msgType = 'danger';
            }
        }
    }
}

/* ================= UPDATE PROFIL ================= */
if (isset($_POST['update'])) {
    $nama  = trim($_POST['nama_pengguna']);
    $email = trim($_POST['email']);

    $s = $conn->prepare("UPDATE pengguna SET nama_pengguna=?, email=? WHERE id_pengguna=?");
    $s->bind_param("ssi", $nama, $email, $id);
    $ok = $s->execute();
    $s->close();

    $msg     = $ok ? 'Profil berhasil diperbarui!' : 'Gagal memperbarui profil!';
    $msgType = $ok ? 'success' : 'danger';

    if ($ok) {
        $stmt = $conn->prepare("SELECT * FROM pengguna WHERE id_pengguna=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
}

/* ================= UBAH PASSWORD ================= */
if (isset($_POST['change_pass'])) {
    $old     = $_POST['old_password'];
    $new     = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if ($new !== $confirm) {
        $msg = 'Konfirmasi password tidak cocok!';
        $msgType = 'danger';
    } elseif (!password_verify($old, $user['password'])) {
        $msg = 'Password lama salah!';
        $msgType = 'danger';
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $s = $conn->prepare("UPDATE pengguna SET password=? WHERE id_pengguna=?");
        $s->bind_param("si", $hash, $id);
        $ok = $s->execute();
        $s->close();

        $msg     = $ok ? 'Password berhasil diubah!' : 'Gagal mengubah password!';
        $msgType = $ok ? 'success' : 'danger';
    }
}

// Inisial untuk avatar fallback
$initials = '';
foreach (explode(' ', trim($user['nama_pengguna'])) as $w) {
    $initials .= strtoupper(mb_substr($w, 0, 1));
    if (strlen($initials) >= 2) break;
}

$fotoSrc = (!empty($user['foto']) && file_exists('../' . $user['foto']))
           ? '../' . htmlspecialchars($user['foto'])
           : null;

$page_title = 'Profil Saya';
$page_sub   = 'Kelola informasi akun';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil — Admin Perpustakaan</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    :root {
        --primary-50: #eef2ff;
        --primary-100: #e0e7ff;
        --primary-200: #c7d2fe;
        --primary-300: #a5b4fc;
        --primary-400: #818cf8;
        --primary-500: #6366f1;
        --primary-600: #4f46e5;
        --primary-700: #4338ca;
        --primary-800: #3730a3;
        --primary-900: #312e81;

        --neutral-50: #f9fafb;
        --neutral-100: #f3f4f6;
        --neutral-200: #e5e7eb;
        --neutral-300: #d1d5db;
        --neutral-400: #9ca3af;
        --neutral-500: #6b7280;
        --neutral-600: #4b5563;
        --neutral-700: #374151;
        --neutral-800: #1f2937;
        --neutral-900: #111827;

        --success-50: #ecfdf5;
        --success-500: #10b981;
        --success-600: #059669;

        --warning-50: #fffbeb;
        --warning-500: #f59e0b;
        --warning-600: #d97706;

        --danger-50: #fef2f2;
        --danger-500: #ef4444;
        --danger-600: #dc2626;

        --info-50: #eff6ff;
        --info-500: #3b82f6;

        --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);

        --radius-sm: 0.375rem;
        --radius-md: 0.5rem;
        --radius-lg: 0.75rem;
        --radius-xl: 1rem;
        --radius-2xl: 1.5rem;
        --radius-3xl: 2rem;
        --radius-full: 9999px;

        --transition: all 0.3s ease;
    }

    body {
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }

    .app-wrap {
        display: flex;
        min-height: 100vh;
    }

    /* ===== SIDEBAR ===== */
    .sidebar {
        width: 280px;
        background: white;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.05);
        display: flex;
        flex-direction: column;
        position: relative;
        z-index: 10;
    }

    .sidebar-brand {
        padding: 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .brand-icon {
        width: 48px;
        height: 48px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: white;
        box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
    }

    .brand-name {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1.3;
    }

    .brand-role {
        font-size: 0.7rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .sidebar-nav {
        flex: 1;
        padding: 20px 16px;
        overflow-y: auto;
    }

    .nav-section-label {
        display: block;
        font-size: 0.65rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--neutral-400);
        margin: 20px 0 8px 12px;
    }

    .nav-section-label:first-of-type {
        margin-top: 0;
    }

    .nav-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        border-radius: var(--radius-lg);
        color: var(--neutral-600);
        text-decoration: none;
        transition: var(--transition);
        margin-bottom: 2px;
        font-weight: 500;
        font-size: 0.9rem;
    }

    .nav-link i {
        width: 20px;
        font-size: 1rem;
        color: var(--neutral-400);
        transition: var(--transition);
    }

    .nav-link:hover {
        background: var(--primary-50);
        color: var(--primary-600);
    }

    .nav-link:hover i {
        color: var(--primary-500);
    }

    .nav-link.active {
        background: var(--primary-50);
        color: var(--primary-700);
        font-weight: 600;
    }

    .nav-link.active i {
        color: var(--primary-600);
    }

    .nav-link.logout {
        margin-top: 20px;
        border-top: 1px solid var(--neutral-200);
        padding-top: 20px;
        color: var(--danger-500);
    }

    .nav-link.logout i {
        color: var(--danger-400);
    }

    .nav-link.logout:hover {
        background: var(--danger-50);
    }

    .sidebar-foot {
        padding: 20px 16px;
        border-top: 1px solid var(--neutral-200);
    }

    /* ===== MAIN AREA ===== */
    .main-area {
        flex: 1;
        background: var(--neutral-50);
        display: flex;
        flex-direction: column;
    }

    /* Header */
    .topbar {
        background: white;
        padding: 16px 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--shadow-sm);
    }

    .page-info {
        display: flex;
        flex-direction: column;
    }

    .page-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--neutral-900);
        margin-bottom: 4px;
    }

    .page-breadcrumb {
        font-size: 0.8rem;
        color: var(--neutral-500);
    }

    .topbar-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .topbar-date {
        font-size: 0.9rem;
        color: var(--neutral-600);
        background: var(--neutral-100);
        padding: 6px 12px;
        border-radius: var(--radius-full);
    }

    .topbar-user {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 12px 4px 4px;
        background: var(--neutral-100);
        border-radius: var(--radius-full);
    }

    .topbar-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
        overflow: hidden;
    }

    .topbar-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .topbar-username {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--neutral-700);
    }

    .btn-logout {
        background: var(--danger-50);
        color: var(--danger-600);
        border: none;
        border-radius: var(--radius-full);
        padding: 8px 16px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
        transition: var(--transition);
    }

    .btn-logout:hover {
        background: var(--danger-100);
    }

    /* Content */
    .content {
        padding: 24px;
        overflow-y: auto;
    }

    /* Alert */
    .profil-alert {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px 20px;
        border-radius: var(--radius-lg);
        margin-bottom: 24px;
        animation: slideDown 0.3s ease;
        border-left: 4px solid;
    }

    .profil-alert.success {
        background: #f0fdf4;
        border-left-color: var(--success-500);
        color: #166534;
    }

    .profil-alert.danger {
        background: #fef2f2;
        border-left-color: var(--danger-500);
        color: #991b1b;
    }

    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Profile Layout */
    .profil-wrap {
        display: grid;
        grid-template-columns: 320px 1fr;
        gap: 24px;
        align-items: start;
        max-width: 1000px;
        margin: 0 auto;
    }

    /* ===== LEFT COLUMN ===== */
    .profil-sidebar {}

    /* Identity card */
    .id-card {
        background: white;
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-2xl);
        box-shadow: var(--shadow-md);
        overflow: hidden;
        margin-bottom: 20px;
    }

    .id-card-banner {
        height: 100px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700), var(--primary-800));
        position: relative;
    }

    .id-card-banner::before {
        content: '';
        position: absolute;
        inset: 0;
        background: url('data:image/svg+xml,<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><path d="M30 0 L60 30 L30 60 L0 30 Z" fill="rgba(255,255,255,0.03)"/></svg>');
        background-size: 20px 20px;
        opacity: 0.3;
    }

    .id-card-body {
        padding: 0 24px 24px;
        text-align: center;
    }

    /* Avatar */
    .avatar-ring {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        border: 4px solid white;
        box-shadow: var(--shadow-lg);
        margin: -50px auto 16px;
        position: relative;
        cursor: pointer;
        transition: var(--transition);
        background: white;
    }

    .avatar-ring:hover {
        transform: scale(1.05);
    }

    .avatar-ring:hover .avatar-overlay {
        opacity: 1;
    }

    .avatar-img {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        object-fit: cover;
        display: block;
    }

    .avatar-initials {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 2rem;
        font-weight: 700;
        color: white;
    }

    .avatar-overlay {
        position: absolute;
        inset: 0;
        border-radius: 50%;
        background: rgba(67, 97, 238, 0.8);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s;
        gap: 2px;
        color: white;
        backdrop-filter: blur(2px);
    }

    .avatar-overlay i {
        font-size: 1.2rem;
    }

    .avatar-overlay span {
        font-size: 0.6rem;
        font-weight: 600;
        text-transform: uppercase;
    }

    .avatar-cam {
        position: absolute;
        bottom: 2px;
        right: 2px;
        width: 28px;
        height: 28px;
        background: var(--primary-600);
        border: 2px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 0.8rem;
        box-shadow: var(--shadow-md);
    }

    .profil-name {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.2rem;
        font-weight: 700;
        color: var(--neutral-900);
        margin-bottom: 4px;
    }

    .profil-role-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: var(--primary-50);
        color: var(--primary-700);
        border: 1px solid var(--primary-100);
        border-radius: var(--radius-full);
        padding: 6px 16px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-bottom: 20px;
    }

    /* Meta info rows */
    .id-meta {
        text-align: left;
        border-top: 1px solid var(--neutral-200);
        padding-top: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .id-meta-row {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .id-meta-icon {
        width: 36px;
        height: 36px;
        background: var(--neutral-100);
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: var(--neutral-600);
    }

    .id-meta-content {
        flex: 1;
    }

    .id-meta-label {
        font-size: 0.7rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.06em;
        font-weight: 600;
        margin-bottom: 2px;
    }

    .id-meta-val {
        font-size: 0.85rem;
        color: var(--neutral-800);
        font-weight: 500;
        word-break: break-all;
    }

    /* Photo upload card */
    .foto-upload-card {
        background: white;
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-sm);
        padding: 20px;
    }

    .foto-upload-title {
        font-size: 0.8rem;
        font-weight: 600;
        color: var(--neutral-700);
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .foto-upload-title i {
        color: var(--primary-500);
    }

    .foto-drop-zone {
        border: 2px dashed var(--neutral-300);
        border-radius: var(--radius-lg);
        padding: 20px 12px;
        text-align: center;
        cursor: pointer;
        transition: var(--transition);
        background: var(--neutral-50);
    }

    .foto-drop-zone:hover {
        border-color: var(--primary-500);
        background: var(--primary-50);
    }

    .foto-drop-zone.dragover {
        border-color: var(--primary-500);
        background: var(--primary-50);
    }

    .foto-drop-icon {
        width: 48px;
        height: 48px;
        background: var(--primary-50);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        color: var(--primary-500);
        font-size: 1.3rem;
    }

    .foto-drop-label {
        font-size: 0.85rem;
        color: var(--neutral-600);
        line-height: 1.5;
    }

    .foto-drop-label strong {
        color: var(--primary-600);
        cursor: pointer;
    }

    .foto-hint {
        font-size: 0.7rem;
        color: var(--neutral-500);
        margin-top: 8px;
        line-height: 1.4;
    }

    .foto-filename {
        font-size: 0.8rem;
        color: var(--success-600);
        font-weight: 500;
        margin-top: 8px;
        display: none;
        word-break: break-all;
    }

    .btn-upload {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 20px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        color: white;
        border: none;
        border-radius: var(--radius-lg);
        font-family: 'Inter', sans-serif;
        font-size: 0.9rem;
        font-weight: 600;
        cursor: pointer;
        transition: var(--transition);
        width: 100%;
        justify-content: center;
        margin-top: 16px;
    }

    .btn-upload:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg);
    }

    /* ===== RIGHT COLUMN ===== */
    .profil-forms {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    /* Form cards */
    .form-card {
        background: white;
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-md);
        overflow: hidden;
    }

    .form-card-header {
        padding: 20px 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        gap: 12px;
        background: linear-gradient(135deg, var(--neutral-50), white);
    }

    .form-card-icon {
        width: 40px;
        height: 40px;
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 1.1rem;
    }

    .form-card-icon.blue {
        background: var(--primary-50);
        color: var(--primary-600);
    }

    .form-card-icon.gold {
        background: var(--warning-50);
        color: var(--warning-600);
    }

    .form-card-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1rem;
        font-weight: 700;
        color: var(--neutral-900);
    }

    .form-card-sub {
        font-size: 0.8rem;
        color: var(--neutral-500);
        margin-top: 2px;
    }

    .form-card-body {
        padding: 24px;
    }

    .form-card-footer {
        padding: 16px 24px;
        background: var(--neutral-50);
        border-top: 1px solid var(--neutral-200);
        display: flex;
        justify-content: flex-end;
    }

    /* Form fields */
    .field-group {
        margin-bottom: 20px;
    }

    .field-group:last-child {
        margin-bottom: 0;
    }

    .field-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .field-label {
        display: block;
        font-size: 0.8rem;
        font-weight: 600;
        color: var(--neutral-700);
        letter-spacing: 0.03em;
        margin-bottom: 6px;
    }

    .field-label span {
        color: var(--danger-500);
        margin-left: 2px;
    }

    .field-input {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-lg);
        font-family: 'Inter', sans-serif;
        font-size: 0.9rem;
        color: var(--neutral-900);
        background: white;
        transition: var(--transition);
    }

    .field-input:focus {
        outline: none;
        border-color: var(--primary-500);
        box-shadow: 0 0 0 3px var(--primary-100);
    }

    .field-input:read-only {
        background: var(--neutral-100);
        color: var(--neutral-500);
        cursor: default;
    }

    .field-note {
        font-size: 0.7rem;
        color: var(--neutral-500);
        margin-top: 4px;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    /* Password strength */
    .pass-strength {
        margin-top: 8px;
        display: flex;
        gap: 4px;
    }

    .strength-bar {
        height: 4px;
        flex: 1;
        border-radius: var(--radius-full);
        background: var(--neutral-200);
        transition: background 0.3s;
    }

    .strength-bar.weak {
        background: var(--danger-500);
    }

    .strength-bar.medium {
        background: var(--warning-500);
    }

    .strength-bar.strong {
        background: var(--success-500);
    }

    .strength-text {
        font-size: 0.7rem;
        color: var(--neutral-500);
        margin-top: 4px;
    }

    /* Buttons */
    .btn-save {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 24px;
        background: var(--primary-600);
        color: white;
        border: none;
        border-radius: var(--radius-lg);
        font-family: 'Inter', sans-serif;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        transition: var(--transition);
        box-shadow: 0 4px 6px -1px rgba(67, 97, 238, 0.3);
    }

    .btn-save:hover {
        background: var(--primary-700);
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg);
    }

    .btn-save.teal {
        background: #2563eb;
    }

    .btn-save.teal:hover {
        background: #2563eb;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .profil-wrap {
            grid-template-columns: 1fr;
        }

        .field-row {
            grid-template-columns: 1fr;
        }
    }
    </style>
</head>

<body>
    <div class="app-wrap">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <div class="brand-icon">📚</div>
                <div>
                    <div class="brand-name">Perpustakaan Digital</div>
                    <div class="brand-role">ADMINISTRATOR</div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <span class="nav-section-label">UTAMA</span>
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>

                <span class="nav-section-label">MANAJEMEN</span>
                <a href="pengguna.php" class="nav-link">
                    <i class="fas fa-users-cog"></i>
                    <span>Pengguna</span>
                </a>
                <a href="anggota.php" class="nav-link">
                    <i class="fas fa-user-graduate"></i>
                    <span>Anggota</span>
                </a>

                <span class="nav-section-label">KOLEKSI</span>
                <a href="kategori.php" class="nav-link">
                    <i class="fas fa-tags"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php" class="nav-link">
                    <i class="fas fa-book"></i>
                    <span>Buku</span>
                </a>

                <span class="nav-section-label">TRANSAKSI</span>
                <a href="transaksi.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transaksi</span>
                </a>
                <a href="denda.php" class="nav-link">
                    <i class="fas fa-coins"></i>
                    <span>Denda</span>
                </a>
                <a href="laporan.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>

                <span class="nav-section-label">AKUN</span>
                <a href="profil.php" class="nav-link active">
                    <i class="fas fa-user"></i>
                    <span>Profil Saya</span>
                </a>
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-globe"></i>
                    <span>Beranda</span>
                </a>
            </nav>

            <div class="sidebar-foot">
                <a href="logout.php" class="nav-link logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- MAIN AREA -->
        <div class="main-area">
            <!-- HEADER -->
            <header class="topbar">
                <div class="page-info">
                    <h1 class="page-title"><?= htmlspecialchars($page_title) ?></h1>
                    <div class="page-breadcrumb"><?= htmlspecialchars($page_sub) ?></div>
                </div>
                <div class="topbar-right">
                    <div class="topbar-date">
                        <i class="far fa-calendar-alt"></i> <?= date('d M Y') ?>
                    </div>
                    <div class="topbar-user">
                        <div class="topbar-avatar">
                            <?php if ($fotoPathHeader): ?>
                            <img src="<?= $fotoPathHeader ?>" alt="Foto">
                            <?php else: ?>
                            <?= htmlspecialchars($initialsHeader) ?>
                            <?php endif; ?>
                        </div>
                        <span class="topbar-username"><?= htmlspecialchars(getPenggunaName()) ?></span>
                    </div>
                    <a href="logout.php" class="btn-logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </header>

            <!-- CONTENT -->
            <main class="content">
                <?php if ($msg): ?>
                <div class="profil-alert <?= $msgType ?>">
                    <i class="fas <?= $msgType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
                    <?= htmlspecialchars($msg) ?>
                </div>
                <?php endif; ?>

                <div class="profil-wrap">
                    <!-- LEFT COLUMN - Profile Card -->
                    <div class="profil-sidebar">
                        <!-- ID Card -->
                        <div class="id-card">
                            <div class="id-card-banner"></div>
                            <div class="id-card-body">
                                <!-- Avatar -->
                                <label for="fotoInput" style="display:block;width:fit-content;margin:0 auto">
                                    <div class="avatar-ring">
                                        <?php if ($fotoSrc): ?>
                                        <img src="<?= $fotoSrc ?>" alt="Foto Profil" class="avatar-img"
                                            id="avatarPreview">
                                        <?php else: ?>
                                        <div class="avatar-initials" id="avatarInitials">
                                            <?= htmlspecialchars($initials) ?></div>
                                        <img src="" alt="" class="avatar-img" id="avatarPreview" style="display:none">
                                        <?php endif; ?>
                                        <div class="avatar-overlay">
                                            <i class="fas fa-camera"></i>
                                            <span>Ganti</span>
                                        </div>
                                        <div class="avatar-cam">
                                            <i class="fas fa-camera"></i>
                                        </div>
                                    </div>
                                </label>

                                <div class="profil-name"><?= htmlspecialchars($user['nama_pengguna']) ?></div>
                                <div class="profil-role-badge">
                                    <i class="fas fa-crown"></i>
                                    Administrator Sistem
                                </div>

                                <div class="id-meta">
                                    <div class="id-meta-row">
                                        <div class="id-meta-icon">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                        <div class="id-meta-content">
                                            <div class="id-meta-label">Email</div>
                                            <div class="id-meta-val"><?= htmlspecialchars($user['email'] ?? '—') ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="id-meta-row">
                                        <div class="id-meta-icon">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="id-meta-content">
                                            <div class="id-meta-label">Username</div>
                                            <div class="id-meta-val"><?= htmlspecialchars($user['username']) ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Photo upload form -->
                        <div class="foto-upload-card">
                            <div class="foto-upload-title">
                                <i class="fas fa-cloud-upload-alt"></i>
                                Foto Profil
                            </div>
                            <form method="POST" enctype="multipart/form-data" id="fotoForm">
                                <div class="foto-drop-zone" id="dropZone"
                                    onclick="document.getElementById('fotoInput').click()">
                                    <div class="foto-drop-icon">
                                        <i class="fas fa-images"></i>
                                    </div>
                                    <div class="foto-drop-label">
                                        Seret foto ke sini atau<br><strong>klik untuk memilih</strong>
                                    </div>
                                    <div class="foto-hint">JPG, PNG, WebP · Maks. 2 MB</div>
                                    <div class="foto-filename" id="fotoFilename"></div>
                                </div>
                                <input type="file" id="fotoInput" name="foto" accept=".jpg,.jpeg,.png,.webp"
                                    style="display:none">
                                <button type="submit" name="upload_foto" class="btn-upload">
                                    <i class="fas fa-upload"></i>
                                    Simpan Foto
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN - Forms -->
                    <div class="profil-forms">
                        <!-- Edit Info -->
                        <div class="form-card">
                            <div class="form-card-header">
                                <div class="form-card-icon blue">
                                    <i class="fas fa-user-edit"></i>
                                </div>
                                <div>
                                    <div class="form-card-title">Informasi Akun</div>
                                    <div class="form-card-sub">Perbarui nama dan alamat email</div>
                                </div>
                            </div>
                            <form method="POST">
                                <div class="form-card-body">
                                    <div class="field-group">
                                        <label class="field-label">Nama Lengkap <span>*</span></label>
                                        <input name="nama_pengguna" class="field-input"
                                            value="<?= htmlspecialchars($user['nama_pengguna']) ?>" required
                                            placeholder="Masukkan nama lengkap">
                                    </div>
                                    <div class="field-group">
                                        <label class="field-label">Alamat Email</label>
                                        <input name="email" type="email" class="field-input"
                                            value="<?= htmlspecialchars($user['email'] ?? '') ?>"
                                            placeholder="contoh@email.com">
                                    </div>
                                    <div class="field-group">
                                        <label class="field-label">Username</label>
                                        <input class="field-input" value="<?= htmlspecialchars($user['username']) ?>"
                                            readonly>
                                        <div class="field-note">
                                            <i class="fas fa-info-circle"></i>
                                            Username tidak dapat diubah
                                        </div>
                                    </div>
                                </div>
                                <div class="form-card-footer">
                                    <button name="update" class="btn-save">
                                        <i class="fas fa-save"></i>
                                        Simpan Perubahan
                                    </button>
                                </div>
                            </form>
                        </div>

                        <!-- Change Password -->
                        <div class="form-card">
                            <div class="form-card-header">
                                <div class="form-card-icon gold">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div>
                                    <div class="form-card-title">Ubah Password</div>
                                    <div class="form-card-sub">Gunakan password yang kuat dan unik</div>
                                </div>
                            </div>
                            <form method="POST">
                                <div class="form-card-body">
                                    <div class="field-group">
                                        <label class="field-label">Password Saat Ini <span>*</span></label>
                                        <input name="old_password" type="password" class="field-input" required
                                            placeholder="Masukkan password lama">
                                    </div>
                                    <div class="field-row">
                                        <div class="field-group">
                                            <label class="field-label">Password Baru <span>*</span></label>
                                            <input name="new_password" type="password" class="field-input" required
                                                id="newPassInput" placeholder="Min. 8 karakter"
                                                oninput="checkStrength(this.value)">
                                            <div class="pass-strength" id="strengthBars">
                                                <div class="strength-bar" id="bar1"></div>
                                                <div class="strength-bar" id="bar2"></div>
                                                <div class="strength-bar" id="bar3"></div>
                                                <div class="strength-bar" id="bar4"></div>
                                            </div>
                                            <div class="strength-text" id="strengthText"></div>
                                        </div>
                                        <div class="field-group">
                                            <label class="field-label">Konfirmasi Password <span>*</span></label>
                                            <input name="confirm_password" type="password" class="field-input" required
                                                id="confirmPassInput" placeholder="Ulangi password baru"
                                                oninput="checkMatch()">
                                            <div class="field-note" id="matchNote" style="display:none"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-card-footer">
                                    <button name="change_pass" class="btn-save teal">
                                        <i class="fas fa-key"></i>
                                        Ubah Password
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
    // Foto upload handling
    const fotoInput = document.getElementById('fotoInput');
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarInitials = document.getElementById('avatarInitials');
    const fotoFilename = document.getElementById('fotoFilename');
    const dropZone = document.getElementById('dropZone');

    fotoInput.addEventListener('change', function() {
        handleFile(this.files[0]);
    });

    function handleFile(file) {
        if (!file) return;

        const allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowed.includes(file.type)) {
            alert('Format tidak didukung. Gunakan JPG, PNG, atau WebP.');
            fotoInput.value = '';
            return;
        }

        if (file.size > 2 * 1024 * 1024) {
            alert('Ukuran file melebihi 2 MB.');
            fotoInput.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = e => {
            if (avatarPreview) {
                avatarPreview.src = e.target.result;
                avatarPreview.style.display = 'block';
                if (avatarInitials) avatarInitials.style.display = 'none';
            }
        };
        reader.readAsDataURL(file);

        if (fotoFilename) {
            fotoFilename.textContent = '📎 ' + file.name;
            fotoFilename.style.display = 'block';
        }
    }

    // Drag and drop
    if (dropZone) {
        dropZone.addEventListener('dragover', e => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('dragover');

            const file = e.dataTransfer.files[0];
            if (file) {
                const dt = new DataTransfer();
                dt.items.add(file);
                fotoInput.files = dt.files;
                handleFile(file);
            }
        });
    }

    // Password strength indicator
    function checkStrength(val) {
        const bars = [
            document.getElementById('bar1'),
            document.getElementById('bar2'),
            document.getElementById('bar3'),
            document.getElementById('bar4')
        ];
        const txt = document.getElementById('strengthText');

        if (!bars[0] || !txt) return;

        bars.forEach(b => {
            if (b) b.className = 'strength-bar';
        });

        if (!val) {
            txt.textContent = '';
            return;
        }

        let score = 0;
        if (val.length >= 8) score++;
        if (/[A-Z]/.test(val)) score++;
        if (/[0-9]/.test(val)) score++;
        if (/[^A-Za-z0-9]/.test(val)) score++;

        const levels = ['', 'weak', 'medium', 'medium', 'strong'];
        const labels = ['', 'Lemah', 'Cukup', 'Baik', 'Kuat'];

        for (let i = 0; i < score; i++) {
            if (bars[i]) bars[i].classList.add(levels[score]);
        }

        txt.textContent = labels[score] ? 'Kekuatan: ' + labels[score] : '';
        txt.style.color = score === 4 ? 'var(--success-500)' : score >= 2 ? 'var(--warning-500)' : 'var(--danger-500)';
    }

    // Password match check
    function checkMatch() {
        const np = document.getElementById('newPassInput');
        const cp = document.getElementById('confirmPassInput');
        const note = document.getElementById('matchNote');

        if (!np || !cp || !note) return;

        if (!cp.value) {
            note.style.display = 'none';
            return;
        }

        note.style.display = 'flex';

        if (np.value === cp.value) {
            note.innerHTML = '<i class="fas fa-check-circle"></i> Password cocok';
            note.style.color = 'var(--success-600)';
        } else {
            note.innerHTML = '<i class="fas fa-exclamation-circle"></i> Password tidak cocok';
            note.style.color = 'var(--danger-600)';
        }
    }

    // Prevent form resubmission
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
    <script src="../assets/js/script.js"></script>
</body>

</html>