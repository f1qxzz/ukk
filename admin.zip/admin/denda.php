<?php
require_once '../config/database.php';
require_once '../includes/session.php';
requireAdmin();

// Definisikan konstanta DENDA_PER_HARI jika belum didefinisikan
if (!defined('DENDA_PER_HARI')) {
    define('DENDA_PER_HARI', 1000); // Rp 1.000 per hari
}

$conn = getConnection();
$msg = ''; $msgType = '';

// Ambil data user untuk header
$userId = getPenggunaId();
$userStmt = $conn->prepare("SELECT foto, nama_pengguna FROM pengguna WHERE id_pengguna = ?");
$userStmt->bind_param("i", $userId);
$userStmt->execute();
$userData = $userStmt->get_result()->fetch_assoc();
$userStmt->close();

// Inisial untuk avatar
$initials = '';
foreach (explode(' ', trim($userData['nama_pengguna'] ?? getPenggunaName())) as $w) {
    $initials .= strtoupper(mb_substr($w, 0, 1));
    if (strlen($initials) >= 2) break;
}
$fotoPath = (!empty($userData['foto']) && file_exists('../' . $userData['foto'])) 
            ? '../' . htmlspecialchars($userData['foto']) 
            : null;

// Proses pembayaran denda
if (isset($_POST['bayar'])) {
    $id = (int)$_POST['id_denda'];
    $s = $conn->prepare("UPDATE denda SET status_bayar='sudah', tgl_bayar=NOW() WHERE id_denda=?");
    $s->bind_param("i", $id);
    if ($s->execute()) {
        $msg = 'Denda berhasil dibayar!';
        $msgType = 'success';
    } else {
        $msg = 'Gagal membayar denda!';
        $msgType = 'danger';
    }
    $s->close();
}

// Hitung dan buat denda otomatis untuk yang terlambat
$overdue = $conn->query("SELECT t.id_transaksi, t.tgl_kembali_rencana FROM transaksi t
    LEFT JOIN denda d ON t.id_transaksi = d.id_transaksi
    WHERE t.status_transaksi = 'Peminjaman' AND t.tgl_kembali_rencana < NOW() AND d.id_denda IS NULL");
while ($od = $overdue->fetch_assoc()) {
    $hari = max(1, floor((time() - strtotime($od['tgl_kembali_rencana'])) / 86400));
    $total = $hari * DENDA_PER_HARI;
    $conn->query("INSERT INTO denda(id_transaksi, jumlah_hari, tarif_per_hari, total_denda) 
                   VALUES({$od['id_transaksi']}, $hari, " . DENDA_PER_HARI . ", $total)");
}

$filter = isset($_GET['f']) ? $_GET['f'] : 'semua';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$q = "SELECT d.*, 
             t.tgl_pinjam, t.tgl_kembali_rencana,
             a.id_anggota, a.nama_anggota, a.nis, a.kelas,
             b.judul_buku, b.isbn, b.cover
      FROM denda d
      JOIN transaksi t ON d.id_transaksi = t.id_transaksi
      JOIN anggota a ON t.id_anggota = a.id_anggota
      JOIN buku b ON t.id_buku = b.id_buku
      WHERE 1=1";

if ($filter === 'belum') $q .= " AND d.status_bayar = 'belum'";
elseif ($filter === 'sudah') $q .= " AND d.status_bayar = 'sudah'";

if (!empty($search)) {
    $search = $conn->real_escape_string($search);
    $q .= " AND (a.nama_anggota LIKE '%$search%' 
                OR a.nis LIKE '%$search%' 
                OR b.judul_buku LIKE '%$search%')";
}

$q .= " ORDER BY d.created_at DESC";
$dendas = $conn->query($q);

// Statistik
$total_denda = $conn->query("SELECT COALESCE(SUM(total_denda), 0) as total FROM denda")->fetch_assoc()['total'];
$total_belum = $conn->query("SELECT COALESCE(SUM(total_denda), 0) as total FROM denda WHERE status_bayar = 'belum'")->fetch_assoc()['total'];
$total_sudah = $conn->query("SELECT COALESCE(SUM(total_denda), 0) as total FROM denda WHERE status_bayar = 'sudah'")->fetch_assoc()['total'];
$jumlah_belum = $conn->query("SELECT COUNT(*) as jml FROM denda WHERE status_bayar = 'belum'")->fetch_assoc()['jml'];

$page_title = 'Monitoring Denda';
$page_sub   = 'Kelola denda keterlambatan pengembalian';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Denda — Admin Perpustakaan</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    :root {
        --primary-50: #eef2ff;
        --primary-100: #e0e7ff;
        --primary-200: #c7d2fe;
        --primary-300: #a5b4fc;
        --primary-400: #818cf8;
        --primary-500: #6366f1;
        --primary-600: #4f46e5;
        --primary-700: #4338ca;
        --primary-800: #3730a3;
        --primary-900: #312e81;

        --neutral-50: #f9fafb;
        --neutral-100: #f3f4f6;
        --neutral-200: #e5e7eb;
        --neutral-300: #d1d5db;
        --neutral-400: #9ca3af;
        --neutral-500: #6b7280;
        --neutral-600: #4b5563;
        --neutral-700: #374151;
        --neutral-800: #1f2937;
        --neutral-900: #111827;

        --success-50: #ecfdf5;
        --success-500: #10b981;
        --success-600: #059669;

        --warning-50: #fffbeb;
        --warning-500: #f59e0b;
        --warning-600: #d97706;

        --danger-50: #fef2f2;
        --danger-500: #ef4444;
        --danger-600: #dc2626;

        --info-50: #eff6ff;
        --info-500: #3b82f6;

        --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);

        --radius-sm: 0.375rem;
        --radius-md: 0.5rem;
        --radius-lg: 0.75rem;
        --radius-xl: 1rem;
        --radius-2xl: 1.5rem;
        --radius-3xl: 2rem;
        --radius-full: 9999px;

        --transition: all 0.3s ease;
    }

    body {
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }

    .app-wrap {
        display: flex;
        min-height: 100vh;
    }

    /* ===== SIDEBAR ===== */
    .sidebar {
        width: 280px;
        background: white;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.05);
        display: flex;
        flex-direction: column;
        position: relative;
        z-index: 10;
    }

    .sidebar-brand {
        padding: 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .brand-icon {
        width: 48px;
        height: 48px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: white;
        box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
    }

    .brand-name {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1.3;
    }

    .brand-role {
        font-size: 0.7rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .sidebar-nav {
        flex: 1;
        padding: 20px 16px;
        overflow-y: auto;
    }

    .nav-section-label {
        display: block;
        font-size: 0.65rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--neutral-400);
        margin: 20px 0 8px 12px;
    }

    .nav-section-label:first-of-type {
        margin-top: 0;
    }

    .nav-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        border-radius: var(--radius-lg);
        color: var(--neutral-600);
        text-decoration: none;
        transition: var(--transition);
        margin-bottom: 2px;
        font-weight: 500;
        font-size: 0.9rem;
    }

    .nav-link i {
        width: 20px;
        font-size: 1rem;
        color: var(--neutral-400);
        transition: var(--transition);
    }

    .nav-link:hover {
        background: var(--primary-50);
        color: var(--primary-600);
    }

    .nav-link:hover i {
        color: var(--primary-500);
    }

    .nav-link.active {
        background: var(--primary-50);
        color: var(--primary-700);
        font-weight: 600;
    }

    .nav-link.active i {
        color: var(--primary-600);
    }

    .nav-link.logout {
        margin-top: 20px;
        border-top: 1px solid var(--neutral-200);
        padding-top: 20px;
        color: var(--danger-500);
    }

    .nav-link.logout i {
        color: var(--danger-400);
    }

    .nav-link.logout:hover {
        background: var(--danger-50);
    }

    .sidebar-foot {
        padding: 20px 16px;
        border-top: 1px solid var(--neutral-200);
    }

    /* ===== MAIN AREA ===== */
    .main-area {
        flex: 1;
        background: var(--neutral-50);
        display: flex;
        flex-direction: column;
    }

    /* Header */
    .topbar {
        background: white;
        padding: 16px 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--shadow-sm);
    }

    .page-info {
        display: flex;
        flex-direction: column;
    }

    .page-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--neutral-900);
        margin-bottom: 4px;
    }

    .page-breadcrumb {
        font-size: 0.8rem;
        color: var(--neutral-500);
    }

    .topbar-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .topbar-date {
        font-size: 0.9rem;
        color: var(--neutral-600);
        background: var(--neutral-100);
        padding: 6px 12px;
        border-radius: var(--radius-full);
    }

    .topbar-user {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 12px 4px 4px;
        background: var(--neutral-100);
        border-radius: var(--radius-full);
    }

    .topbar-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
        overflow: hidden;
    }

    .topbar-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .topbar-username {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--neutral-700);
    }

    .btn-logout {
        background: var(--danger-50);
        color: var(--danger-600);
        border: none;
        border-radius: var(--radius-full);
        padding: 8px 16px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
        transition: var(--transition);
    }

    .btn-logout:hover {
        background: var(--danger-100);
    }

    /* Content */
    .content {
        padding: 24px;
        overflow-y: auto;
    }

    /* Alert */
    .alert {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px 20px;
        border-radius: var(--radius-lg);
        margin-bottom: 24px;
        animation: slideDown 0.3s ease;
        border-left: 4px solid;
    }

    .alert-success {
        background: #f0fdf4;
        border-left-color: var(--success-500);
        color: #166534;
    }

    .alert-danger {
        background: #fef2f2;
        border-left-color: var(--danger-500);
        color: #991b1b;
    }

    .alert-warning {
        background: #fffbeb;
        border-left-color: var(--warning-500);
        color: #92400e;
    }

    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Page Header */
    .page-header {
        background: white;
        border-radius: var(--radius-xl);
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-md);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 20px;
        border: 1px solid var(--neutral-200);
    }

    .page-header-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--neutral-900);
        margin-bottom: 4px;
    }

    .page-header-sub {
        color: var(--neutral-500);
        font-size: 0.95rem;
    }

    /* Stats Cards */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 24px;
    }

    .stat-card {
        background: white;
        border-radius: var(--radius-xl);
        padding: 24px;
        box-shadow: var(--shadow-md);
        border: 1px solid var(--neutral-200);
        transition: var(--transition);
        display: flex;
        flex-direction: column;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-lg);
    }

    .stat-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
    }

    .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    .stat-icon.total {
        background: var(--primary-50);
        color: var(--primary-600);
    }

    .stat-icon.belum {
        background: var(--danger-50);
        color: var(--danger-600);
    }

    .stat-icon.sudah {
        background: var(--success-50);
        color: var(--success-600);
    }

    .stat-icon.jumlah {
        background: var(--warning-50);
        color: var(--warning-600);
    }

    .stat-label {
        font-size: 0.8rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
    }

    .stat-value {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1;
    }

    .stat-sub {
        font-size: 0.75rem;
        color: var(--neutral-500);
        margin-top: 4px;
    }

    .stat-progress {
        margin-top: 12px;
        height: 6px;
        background: var(--neutral-200);
        border-radius: var(--radius-full);
        overflow: hidden;
    }

    .stat-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--primary-500), var(--primary-600));
        border-radius: var(--radius-full);
        transition: width 1s ease;
    }

    /* Filter Bar */
    .filter-bar {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 20px;
        flex-wrap: wrap;
        padding: 0 20px;
    }

    .search-wrap {
        flex: 1;
        min-width: 250px;
    }

    .search-wrap input {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-lg);
        font-size: 0.95rem;
        transition: var(--transition);
    }

    .search-wrap input:focus {
        outline: none;
        border-color: var(--primary-500);
        box-shadow: 0 0 0 3px var(--primary-100);
    }

    .filter-tabs {
        display: flex;
        gap: 8px;
    }

    .filter-tab {
        padding: 8px 16px;
        border: 1px solid var(--neutral-200);
        background: white;
        border-radius: var(--radius-full);
        font-size: 0.85rem;
        font-weight: 500;
        color: var(--neutral-600);
        cursor: pointer;
        text-decoration: none;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .filter-tab:hover {
        background: var(--neutral-50);
        border-color: var(--neutral-300);
    }

    .filter-tab.active {
        background: var(--primary-600);
        color: white;
        border-color: var(--primary-600);
    }

    .filter-tab i {
        font-size: 0.8rem;
    }

    .btn-ghost {
        padding: 10px 20px;
        border: 1px solid var(--neutral-200);
        background: white;
        border-radius: var(--radius-lg);
        font-weight: 500;
        color: var(--neutral-700);
        cursor: pointer;
        transition: var(--transition);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .btn-ghost:hover {
        background: var(--neutral-50);
        border-color: var(--neutral-300);
    }

    .btn-sm {
        padding: 8px 16px;
        font-size: 0.85rem;
    }

    /* Card */
    .card {
        background: white;
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-md);
        border: 1px solid var(--neutral-200);
        overflow: hidden;
    }

    .card-header {
        padding: 20px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 16px;
        background: linear-gradient(135deg, var(--neutral-50), white);
    }

    .card-header h2 {
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--neutral-800);
    }

    /* Table */
    .table-responsive {
        overflow-x: auto;
        padding: 0 20px 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    thead tr {
        background: linear-gradient(135deg, var(--neutral-50), var(--neutral-100));
    }

    th {
        padding: 16px 20px;
        text-align: left;
        font-weight: 600;
        font-size: 0.85rem;
        color: var(--neutral-600);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        white-space: nowrap;
    }

    td {
        padding: 16px 20px;
        border-bottom: 1px solid var(--neutral-200);
        color: var(--neutral-700);
    }

    tr:hover td {
        background: var(--neutral-50);
    }

    .text-muted {
        color: var(--neutral-500);
    }

    .text-sm {
        font-size: 0.85rem;
    }

    .text-xs {
        font-size: 0.7rem;
    }

    .fw-600 {
        font-weight: 600;
        color: var(--neutral-900);
    }

    /* Badge */
    .badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 12px;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 600;
    }

    .badge-success {
        background: var(--success-50);
        color: var(--success-600);
    }

    .badge-danger {
        background: var(--danger-50);
        color: var(--danger-600);
    }

    /* Button Success */
    .btn-success {
        padding: 8px 16px;
        background: var(--success-500);
        color: white;
        border: none;
        border-radius: var(--radius-md);
        font-size: 0.8rem;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: var(--transition);
    }

    .btn-success:hover {
        background: var(--success-600);
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 48px 20px;
    }

    .empty-state-ico {
        font-size: 3rem;
        margin-bottom: 16px;
        opacity: 0.5;
    }

    .empty-state-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--neutral-500);
        margin-bottom: 8px;
    }

    /* Checkbox */
    .checkbox-select {
        width: 18px;
        height: 18px;
        cursor: pointer;
        accent-color: var(--primary-600);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .filter-bar {
            flex-direction: column;
        }

        .search-wrap {
            width: 100%;
        }

        .filter-tabs {
            width: 100%;
            justify-content: space-between;
        }

        .filter-tab {
            flex: 1;
            text-align: center;
            justify-content: center;
        }

        .card-header {
            flex-direction: column;
        }

        .btn-ghost {
            width: 100%;
            justify-content: center;
        }
    }

    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
    }
    </style>
</head>

<body>
    <div class="app-wrap">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <div class="brand-icon">📚</div>
                <div>
                    <div class="brand-name">Perpustakaan Digital</div>
                    <div class="brand-role">ADMINISTRATOR</div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <span class="nav-section-label">UTAMA</span>
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>

                <span class="nav-section-label">MANAJEMEN</span>
                <a href="pengguna.php" class="nav-link">
                    <i class="fas fa-users-cog"></i>
                    <span>Pengguna</span>
                </a>
                <a href="anggota.php" class="nav-link">
                    <i class="fas fa-user-graduate"></i>
                    <span>Anggota</span>
                </a>

                <span class="nav-section-label">KOLEKSI</span>
                <a href="kategori.php" class="nav-link">
                    <i class="fas fa-tags"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php" class="nav-link">
                    <i class="fas fa-book"></i>
                    <span>Buku</span>
                </a>

                <span class="nav-section-label">TRANSAKSI</span>
                <a href="transaksi.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transaksi</span>
                </a>
                <a href="denda.php" class="nav-link active">
                    <i class="fas fa-coins"></i>
                    <span>Denda</span>
                </a>
                <a href="laporan.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>

                <span class="nav-section-label">AKUN</span>
                <a href="profil.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profil Saya</span>
                </a>
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-globe"></i>
                    <span>Beranda</span>
                </a>
            </nav>

            <div class="sidebar-foot">
                <a href="logout.php" class="nav-link logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- MAIN AREA -->
        <div class="main-area">
            <!-- HEADER -->
            <header class="topbar">
                <div class="page-info">
                    <h1 class="page-title"><?= htmlspecialchars($page_title) ?></h1>
                    <div class="page-breadcrumb"><?= htmlspecialchars($page_sub) ?></div>
                </div>
                <div class="topbar-right">
                    <div class="topbar-date">
                        <i class="far fa-calendar-alt"></i> <?= date('d M Y') ?>
                    </div>
                    <div class="topbar-user">
                        <div class="topbar-avatar">
                            <?php if ($fotoPath): ?>
                            <img src="<?= $fotoPath ?>" alt="Foto">
                            <?php else: ?>
                            <?= htmlspecialchars($initials) ?>
                            <?php endif; ?>
                        </div>
                        <span class="topbar-username"><?= htmlspecialchars(getPenggunaName()) ?></span>
                    </div>
                    <a href="logout.php" class="btn-logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </header>

            <!-- CONTENT -->
            <main class="content">
                <?php if ($msg): ?>
                <div class="alert alert-<?= $msgType ?>">
                    <i
                        class="fas <?= $msgType === 'success' ? 'fa-check-circle' : ($msgType === 'warning' ? 'fa-exclamation-triangle' : 'fa-times-circle') ?>"></i>
                    <?= htmlspecialchars($msg) ?>
                </div>
                <?php endif; ?>

                <!-- Page Header -->
                <div class="page-header">
                    <div>
                        <h1 class="page-header-title">Monitoring Denda</h1>
                        <p class="page-header-sub">Kelola denda keterlambatan pengembalian buku</p>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon total"><i class="fas fa-coins"></i></div>
                        </div>
                        <div class="stat-label">Total Denda</div>
                        <div class="stat-value">Rp <?= number_format($total_denda, 0, ',', '.') ?></div>
                        <div class="stat-sub">Keseluruhan</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon belum"><i class="fas fa-hourglass-half"></i></div>
                        </div>
                        <div class="stat-label">Belum Dibayar</div>
                        <div class="stat-value">Rp <?= number_format($total_belum, 0, ',', '.') ?></div>
                        <div class="stat-sub"><?= $jumlah_belum ?> transaksi</div>
                        <div class="stat-progress">
                            <div class="stat-progress-fill"
                                style="width: <?= $total_denda > 0 ? ($total_belum / $total_denda) * 100 : 0 ?>%"></div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon sudah"><i class="fas fa-check-circle"></i></div>
                        </div>
                        <div class="stat-label">Sudah Dibayar</div>
                        <div class="stat-value">Rp <?= number_format($total_sudah, 0, ',', '.') ?></div>
                        <div class="stat-sub">Lunas</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon jumlah"><i class="fas fa-exclamation-triangle"></i></div>
                        </div>
                        <div class="stat-label">Jumlah Denda</div>
                        <div class="stat-value"><?= $dendas->num_rows ?></div>
                        <div class="stat-sub">Total transaksi denda</div>
                    </div>
                </div>

                <!-- Filter & Table -->
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-list" style="margin-right: 8px; color: var(--primary-600);"></i> Daftar
                            Denda</h2>
                        <div class="filter-tabs">
                            <a href="?f=semua" class="filter-tab <?= $filter === 'semua' ? 'active' : '' ?>">
                                <i class="fas fa-list-ul"></i> Semua
                            </a>
                            <a href="?f=belum" class="filter-tab <?= $filter === 'belum' ? 'active' : '' ?>">
                                <i class="fas fa-hourglass-half"></i> Belum Bayar
                            </a>
                            <a href="?f=sudah" class="filter-tab <?= $filter === 'sudah' ? 'active' : '' ?>">
                                <i class="fas fa-check-circle"></i> Sudah Bayar
                            </a>
                        </div>
                    </div>

                    <form method="GET" class="filter-bar">
                        <div class="search-wrap">
                            <input type="text" name="search" placeholder="Cari anggota atau judul buku..."
                                value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <input type="hidden" name="f" value="<?= htmlspecialchars($filter) ?>">
                        <button type="submit" class="btn-ghost btn-sm"><i class="fas fa-search"></i> Cari</button>
                        <?php if ($search || $filter !== 'semua'): ?>
                        <a href="denda.php" class="btn-ghost btn-sm"><i class="fas fa-times"></i> Reset</a>
                        <?php endif; ?>
                    </form>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Anggota</th>
                                    <th>Buku</th>
                                    <th>Tgl Kembali Rencana</th>
                                    <th>Telat (Hari)</th>
                                    <th>Total Denda</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($dendas && $dendas->num_rows > 0): while($r = $dendas->fetch_assoc()): ?>
                                <tr>
                                    <td class="text-muted text-sm">#<?= $r['id_denda'] ?></td>
                                    <td>
                                        <div class="fw-600"><?= htmlspecialchars($r['nama_anggota']) ?></div>
                                        <div class="text-xs text-muted">NIS: <?= htmlspecialchars($r['nis'] ?? '') ?>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($r['judul_buku']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($r['tgl_kembali_rencana'])) ?></td>
                                    <td><?= $r['jumlah_hari'] ?> hari</td>
                                    <td><span class="fw-600">Rp
                                            <?= number_format($r['total_denda'], 0, ',', '.') ?></span></td>
                                    <td>
                                        <span
                                            class="badge <?= $r['status_bayar'] === 'sudah' ? 'badge-success' : 'badge-danger' ?>">
                                            <i
                                                class="fas <?= $r['status_bayar'] === 'sudah' ? 'fa-check' : 'fa-times' ?>"></i>
                                            <?= $r['status_bayar'] === 'sudah' ? 'Lunas' : 'Belum' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($r['status_bayar'] === 'belum'): ?>
                                        <form method="POST"
                                            onsubmit="return confirm('Konfirmasi pembayaran denda Rp <?= number_format($r['total_denda'], 0, ',', '.') ?>?')"
                                            style="display:inline">
                                            <input type="hidden" name="id_denda" value="<?= $r['id_denda'] ?>">
                                            <button type="submit" name="bayar" class="btn-success btn-sm">
                                                <i class="fas fa-check"></i> Bayar
                                            </button>
                                        </form>
                                        <?php else: ?>
                                        <span class="text-muted text-xs">
                                            <i class="far fa-calendar-check"></i>
                                            <?= date('d/m/Y', strtotime($r['tgl_bayar'])) ?>
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; else: ?>
                                <tr>
                                    <td colspan="8">
                                        <div class="empty-state">
                                            <div class="empty-state-ico">💰</div>
                                            <div class="empty-state-title">Tidak ada data denda</div>
                                            <p class="text-muted text-sm">Belum ada denda yang tercatat dalam sistem</p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
    // Tutup modal dengan ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            // Tidak ada modal di halaman ini
        }
    });

    // Prevent form resubmission
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
    <script src="../assets/js/script.js"></script>
</body>

</html>