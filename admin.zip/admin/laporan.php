<?php
require_once '../config/database.php';
require_once '../includes/session.php';
requireAdmin();

$conn = getConnection();

// Ambil data user untuk header
$userId = getPenggunaId();
$userStmt = $conn->prepare("SELECT foto, nama_pengguna FROM pengguna WHERE id_pengguna = ?");
$userStmt->bind_param("i", $userId);
$userStmt->execute();
$userData = $userStmt->get_result()->fetch_assoc();
$userStmt->close();

// Inisial untuk avatar
$initials = '';
foreach (explode(' ', trim($userData['nama_pengguna'] ?? getPenggunaName())) as $w) {
    $initials .= strtoupper(mb_substr($w, 0, 1));
    if (strlen($initials) >= 2) break;
}
$fotoPath = (!empty($userData['foto']) && file_exists('../' . $userData['foto'])) 
            ? '../' . htmlspecialchars($userData['foto']) 
            : null;

// Statistik
$total_buku     = $conn->query("SELECT COUNT(*) c FROM buku")->fetch_assoc()['c'];
$buku_tersedia  = $conn->query("SELECT COUNT(*) c FROM buku WHERE status='tersedia'")->fetch_assoc()['c'];
$total_anggota  = $conn->query("SELECT COUNT(*) c FROM anggota")->fetch_assoc()['c'];
$total_pinjam   = $conn->query("SELECT COUNT(*) c FROM transaksi")->fetch_assoc()['c'];
$aktif_pinjam   = $conn->query("SELECT COUNT(*) c FROM transaksi WHERE status_transaksi='Peminjaman'")->fetch_assoc()['c'];
$total_denda    = $conn->query("SELECT COALESCE(SUM(total_denda),0) s FROM denda")->fetch_assoc()['s'];
$denda_belum    = $conn->query("SELECT COALESCE(SUM(total_denda),0) s FROM denda WHERE status_bayar='belum'")->fetch_assoc()['s'];

$trans_all = $conn->query("SELECT t.*,a.nama_anggota,a.nis,a.kelas,b.judul_buku,b.cover 
                           FROM transaksi t 
                           JOIN anggota a ON t.id_anggota=a.id_anggota 
                           JOIN buku b ON t.id_buku=b.id_buku 
                           ORDER BY t.tgl_pinjam DESC");
$denda_all = $conn->query("SELECT d.*,a.nama_anggota,b.judul_buku,b.cover 
                           FROM denda d 
                           JOIN transaksi t ON d.id_transaksi=t.id_transaksi 
                           JOIN anggota a ON t.id_anggota=a.id_anggota 
                           JOIN buku b ON t.id_buku=b.id_buku 
                           ORDER BY d.id_denda DESC");

$page_title = 'Laporan Sistem';
$page_sub   = 'Rekap data dan statistik perpustakaan';
$no_laporan = 'RPT-' . date('Ymd') . '-001';
$tgl_cetak  = date('d F Y');
$jam_cetak  = date('H:i') . ' WIB';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan — Admin Perpustakaan</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    :root {
        --primary-50: #eef2ff;
        --primary-100: #e0e7ff;
        --primary-200: #c7d2fe;
        --primary-300: #a5b4fc;
        --primary-400: #818cf8;
        --primary-500: #6366f1;
        --primary-600: #4f46e5;
        --primary-700: #4338ca;
        --primary-800: #3730a3;
        --primary-900: #312e81;

        --neutral-50: #f9fafb;
        --neutral-100: #f3f4f6;
        --neutral-200: #e5e7eb;
        --neutral-300: #d1d5db;
        --neutral-400: #9ca3af;
        --neutral-500: #6b7280;
        --neutral-600: #4b5563;
        --neutral-700: #374151;
        --neutral-800: #1f2937;
        --neutral-900: #111827;

        --success-50: #ecfdf5;
        --success-500: #10b981;
        --success-600: #059669;

        --warning-50: #fffbeb;
        --warning-500: #f59e0b;
        --warning-600: #d97706;

        --danger-50: #fef2f2;
        --danger-500: #ef4444;
        --danger-600: #dc2626;

        --info-50: #eff6ff;
        --info-500: #3b82f6;

        --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);

        --radius-sm: 0.375rem;
        --radius-md: 0.5rem;
        --radius-lg: 0.75rem;
        --radius-xl: 1rem;
        --radius-2xl: 1.5rem;
        --radius-3xl: 2rem;
        --radius-full: 9999px;

        --transition: all 0.3s ease;
    }

    body {
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }

    .app-wrap {
        display: flex;
        min-height: 100vh;
    }

    /* ===== SIDEBAR ===== */
    .sidebar {
        width: 280px;
        background: white;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.05);
        display: flex;
        flex-direction: column;
        position: relative;
        z-index: 10;
    }

    .sidebar-brand {
        padding: 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .brand-icon {
        width: 48px;
        height: 48px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: white;
        box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
    }

    .brand-name {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1.3;
    }

    .brand-role {
        font-size: 0.7rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .sidebar-nav {
        flex: 1;
        padding: 20px 16px;
        overflow-y: auto;
    }

    .nav-section-label {
        display: block;
        font-size: 0.65rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--neutral-400);
        margin: 20px 0 8px 12px;
    }

    .nav-section-label:first-of-type {
        margin-top: 0;
    }

    .nav-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        border-radius: var(--radius-lg);
        color: var(--neutral-600);
        text-decoration: none;
        transition: var(--transition);
        margin-bottom: 2px;
        font-weight: 500;
        font-size: 0.9rem;
    }

    .nav-link i {
        width: 20px;
        font-size: 1rem;
        color: var(--neutral-400);
        transition: var(--transition);
    }

    .nav-link:hover {
        background: var(--primary-50);
        color: var(--primary-600);
    }

    .nav-link:hover i {
        color: var(--primary-500);
    }

    .nav-link.active {
        background: var(--primary-50);
        color: var(--primary-700);
        font-weight: 600;
    }

    .nav-link.active i {
        color: var(--primary-600);
    }

    .nav-link.logout {
        margin-top: 20px;
        border-top: 1px solid var(--neutral-200);
        padding-top: 20px;
        color: var(--danger-500);
    }

    .nav-link.logout i {
        color: var(--danger-400);
    }

    .nav-link.logout:hover {
        background: var(--danger-50);
    }

    .sidebar-foot {
        padding: 20px 16px;
        border-top: 1px solid var(--neutral-200);
    }

    /* ===== MAIN AREA ===== */
    .main-area {
        flex: 1;
        background: var(--neutral-50);
        display: flex;
        flex-direction: column;
    }

    /* Header */
    .topbar {
        background: white;
        padding: 16px 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--shadow-sm);
    }

    .page-info {
        display: flex;
        flex-direction: column;
    }

    .page-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--neutral-900);
        margin-bottom: 4px;
    }

    .page-breadcrumb {
        font-size: 0.8rem;
        color: var(--neutral-500);
    }

    .topbar-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .topbar-date {
        font-size: 0.9rem;
        color: var(--neutral-600);
        background: var(--neutral-100);
        padding: 6px 12px;
        border-radius: var(--radius-full);
    }

    .topbar-user {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 12px 4px 4px;
        background: var(--neutral-100);
        border-radius: var(--radius-full);
    }

    .topbar-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
        overflow: hidden;
    }

    .topbar-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .topbar-username {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--neutral-700);
    }

    .btn-logout {
        background: var(--danger-50);
        color: var(--danger-600);
        border: none;
        border-radius: var(--radius-full);
        padding: 8px 16px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
        transition: var(--transition);
    }

    .btn-logout:hover {
        background: var(--danger-100);
    }

    /* Content */
    .content {
        padding: 24px;
        overflow-y: auto;
    }

    /* Page Header */
    .page-header {
        background: white;
        border-radius: var(--radius-xl);
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-md);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 20px;
        border: 1px solid var(--neutral-200);
    }

    .page-header-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--neutral-900);
        margin-bottom: 4px;
    }

    .page-header-sub {
        color: var(--neutral-500);
        font-size: 0.95rem;
    }

    /* Button Primary */
    .btn-primary {
        padding: 12px 24px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        color: white;
        border: none;
        border-radius: var(--radius-lg);
        font-weight: 600;
        font-size: 0.95rem;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: var(--transition);
        box-shadow: 0 4px 6px -1px rgba(67, 97, 238, 0.3);
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(67, 97, 238, 0.4);
    }

    .btn-primary i {
        font-size: 1rem;
    }

    /* Stats Cards */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 24px;
    }

    .stat-card {
        background: white;
        border-radius: var(--radius-xl);
        padding: 24px;
        box-shadow: var(--shadow-md);
        border: 1px solid var(--neutral-200);
        transition: var(--transition);
        display: flex;
        flex-direction: column;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-lg);
    }

    .stat-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
    }

    .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    .stat-icon.blue {
        background: var(--primary-50);
        color: var(--primary-600);
    }

    .stat-icon.green {
        background: var(--success-50);
        color: var(--success-600);
    }

    .stat-icon.orange {
        background: #fff3e0;
        color: #e67e22;
    }

    .stat-icon.red {
        background: var(--danger-50);
        color: var(--danger-600);
    }

    .stat-label {
        font-size: 0.8rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
    }

    .stat-value {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 2rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1;
    }

    .stat-sub {
        font-size: 0.75rem;
        color: var(--neutral-500);
        margin-top: 4px;
    }

    /* Report Container */
    .report-container {
        background: white;
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--neutral-200);
        overflow: hidden;
        margin-top: 24px;
    }

    .report-header {
        padding: 24px;
        border-bottom: 1px solid var(--neutral-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 16px;
        background: linear-gradient(135deg, var(--neutral-50), white);
    }

    .report-header h2 {
        font-size: 1.3rem;
        font-weight: 600;
        color: var(--neutral-800);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .report-header h2 i {
        color: var(--primary-600);
    }

    .report-badge {
        padding: 6px 12px;
        background: var(--primary-50);
        color: var(--primary-700);
        border-radius: var(--radius-full);
        font-size: 0.8rem;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }

    /* ── Report document shell ── */
    .report-document {
        background: white;
        max-width: 1000px;
        margin: 28px auto;
        border: 1px solid var(--neutral-200);
        box-shadow: var(--shadow-xl);
        font-family: 'Inter', sans-serif;
        color: var(--neutral-900);
        position: relative;
        border-radius: var(--radius-2xl);
        overflow: hidden;
    }

    /* Decorative corner marks */
    .report-document::before,
    .report-document::after {
        content: '';
        position: absolute;
        width: 24px;
        height: 24px;
        border-color: var(--primary-500);
        border-style: solid;
        opacity: 0.3;
    }

    .report-document::before {
        top: 20px;
        left: 20px;
        border-width: 3px 0 0 3px;
    }

    .report-document::after {
        bottom: 20px;
        right: 20px;
        border-width: 0 3px 3px 0;
    }

    /* ── Letterhead ── */
    .rpt-letterhead {
        padding: 40px 48px 0;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 24px;
    }

    .rpt-org {
        flex: 1;
    }

    .rpt-logo-mark {
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 16px;
        box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
    }

    .rpt-org-name {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.2rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1.3;
    }

    .rpt-org-sub {
        font-size: 0.85rem;
        color: var(--neutral-500);
        margin-top: 4px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .rpt-meta {
        text-align: right;
        font-size: 0.85rem;
        color: var(--neutral-500);
        line-height: 1.8;
    }

    .rpt-meta strong {
        color: var(--neutral-700);
        font-weight: 600;
    }

    .rpt-doc-number {
        display: inline-block;
        background: var(--neutral-100);
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-full);
        padding: 4px 12px;
        font-family: monospace;
        font-size: 0.8rem;
        color: var(--primary-700);
        letter-spacing: 0.05em;
        margin-bottom: 8px;
    }

    /* ── Title band ── */
    .rpt-title-band {
        margin: 24px 48px 0;
        padding-bottom: 20px;
        border-bottom: 3px solid var(--primary-600);
        display: flex;
        align-items: baseline;
        gap: 16px;
    }

    .rpt-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 2rem;
        font-weight: 800;
        color: var(--neutral-900);
        letter-spacing: -0.02em;
    }

    .rpt-title-sub {
        font-size: 0.9rem;
        color: var(--neutral-500);
        font-style: italic;
    }

    /* ── Stats summary strip ── */
    .rpt-stats {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 0;
        margin: 24px 48px;
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-xl);
        overflow: hidden;
    }

    .rpt-stat {
        padding: 24px 20px;
        border-right: 1px solid var(--neutral-200);
        background: var(--neutral-50);
        position: relative;
    }

    .rpt-stat:last-child {
        border-right: none;
    }

    .rpt-stat-label {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--neutral-500);
        font-weight: 600;
        margin-bottom: 8px;
    }

    .rpt-stat-val {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 2rem;
        font-weight: 700;
        color: var(--neutral-900);
        line-height: 1;
    }

    .rpt-stat-val.money {
        font-size: 1.4rem;
    }

    .rpt-stat-sub {
        font-size: 0.8rem;
        color: var(--neutral-500);
        margin-top: 8px;
    }

    .rpt-stat-bar {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
    }

    .rpt-stat:nth-child(1) .rpt-stat-bar {
        background: var(--primary-500);
    }

    .rpt-stat:nth-child(2) .rpt-stat-bar {
        background: var(--success-500);
    }

    .rpt-stat:nth-child(3) .rpt-stat-bar {
        background: #e67e22;
    }

    .rpt-stat:nth-child(4) .rpt-stat-bar {
        background: var(--danger-500);
    }

    /* ── Section header ── */
    .rpt-section {
        margin: 0 48px 32px;
    }

    .rpt-section-head {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 16px;
        padding-bottom: 8px;
        border-bottom: 2px solid var(--neutral-200);
    }

    .rpt-section-num {
        width: 28px;
        height: 28px;
        background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
        color: white;
        border-radius: var(--radius-full);
        font-size: 0.8rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .rpt-section-title {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--neutral-900);
    }

    .rpt-section-count {
        margin-left: auto;
        font-size: 0.8rem;
        color: var(--neutral-500);
        background: var(--neutral-100);
        border: 1px solid var(--neutral-200);
        border-radius: var(--radius-full);
        padding: 4px 12px;
    }

    /* ── Tables ── */
    .rpt-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.9rem;
    }

    .rpt-table thead tr {
        background: linear-gradient(135deg, var(--neutral-100), var(--neutral-200));
    }

    .rpt-table thead th {
        padding: 12px 16px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.04em;
        font-size: 0.8rem;
        text-transform: uppercase;
        color: var(--neutral-700);
        white-space: nowrap;
    }

    .rpt-table tbody tr {
        border-bottom: 1px solid var(--neutral-200);
        transition: background 0.2s;
    }

    .rpt-table tbody tr:nth-child(even) {
        background: var(--neutral-50);
    }

    .rpt-table tbody tr:hover {
        background: var(--neutral-100);
    }

    .rpt-table tbody tr:last-child {
        border-bottom: 2px solid var(--neutral-300);
    }

    .rpt-table td {
        padding: 12px 16px;
        color: var(--neutral-700);
        vertical-align: middle;
    }

    .rpt-table td.num {
        color: var(--neutral-500);
        font-size: 0.85rem;
        width: 40px;
    }

    .rpt-table td.mono {
        font-family: monospace;
        font-size: 0.85rem;
        color: var(--neutral-600);
    }

    .rpt-table td.name {
        font-weight: 600;
        color: var(--neutral-900);
    }

    .rpt-table td.book {
        font-style: italic;
        color: var(--neutral-700);
        max-width: 250px;
    }

    .rpt-table td.money-cell {
        font-weight: 600;
        color: var(--primary-700);
        white-space: nowrap;
    }

    /* ── Status badges ── */
    .rpt-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid transparent;
    }

    .rpt-badge.kembali {
        background: var(--success-50);
        color: var(--success-600);
        border-color: var(--success-100);
    }

    .rpt-badge.dipinjam {
        background: var(--primary-50);
        color: var(--primary-600);
        border-color: var(--primary-100);
    }

    .rpt-badge.terlambat {
        background: var(--danger-50);
        color: var(--danger-600);
        border-color: var(--danger-100);
    }

    .rpt-badge.lunas {
        background: var(--success-50);
        color: var(--success-600);
        border-color: var(--success-100);
    }

    .rpt-badge.belum {
        background: var(--danger-50);
        color: var(--danger-600);
        border-color: var(--danger-100);
    }

    /* ── Footer ── */
    .rpt-footer {
        margin: 24px 48px 40px;
        padding-top: 24px;
        border-top: 2px solid var(--neutral-200);
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
    }

    .rpt-footer-left {
        font-size: 0.8rem;
        color: var(--neutral-500);
        line-height: 1.7;
    }

    .rpt-signature {
        text-align: center;
        font-size: 0.85rem;
        color: var(--neutral-700);
    }

    .rpt-signature-line {
        width: 160px;
        border-bottom: 2px solid var(--neutral-400);
        margin: 36px auto 8px;
    }

    .rpt-signature-title {
        font-size: 0.7rem;
        color: var(--neutral-500);
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-top: 4px;
    }

    /* ── Empty state ── */
    .rpt-empty {
        text-align: center;
        padding: 40px;
        color: var(--neutral-500);
        font-style: italic;
        font-size: 0.9rem;
    }

    /* ── Print bar (screen only) ── */
    .print-bar-wrap {
        max-width: 1000px;
        margin: 0 auto 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 4px;
    }

    .print-bar-label {
        font-size: 0.9rem;
        color: var(--neutral-600);
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* ── PRINT STYLES ── */
    @media print {

        .screen-only,
        .no-print,
        .sidebar,
        .topbar,
        .page-header,
        .stats-grid,
        .print-bar-wrap {
            display: none !important;
        }

        body {
            background: white;
            margin: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .app-wrap,
        .main-area,
        .content {
            display: block !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        @page {
            size: A4 portrait;
            margin: 2cm;
        }

        .report-document {
            max-width: 100%;
            margin: 0;
            box-shadow: none;
            border: none;
        }

        .rpt-table thead tr {
            background: var(--primary-600) !important;
            color: white !important;
        }

        .rpt-table thead th {
            color: white !important;
        }

        .rpt-badge {
            border: 1px solid #999 !important;
            background: none !important;
            color: #000 !important;
        }

        .rpt-stat {
            background: #f5f5f5 !important;
        }
    }

    /* Responsive */
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .rpt-stats {
            grid-template-columns: repeat(2, 1fr);
        }

        .rpt-letterhead {
            flex-direction: column;
        }

        .rpt-meta {
            text-align: left;
        }

        .rpt-title-band {
            flex-direction: column;
            align-items: flex-start;
        }
    }

    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .rpt-stats {
            grid-template-columns: 1fr;
        }

        .rpt-stat {
            border-right: none;
            border-bottom: 1px solid var(--neutral-200);
        }

        .rpt-stat:last-child {
            border-bottom: none;
        }
    }
    </style>
</head>

<body>
    <div class="app-wrap">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <div class="brand-icon">📚</div>
                <div>
                    <div class="brand-name">Perpustakaan Digital</div>
                    <div class="brand-role">ADMINISTRATOR</div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <span class="nav-section-label">UTAMA</span>
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>

                <span class="nav-section-label">MANAJEMEN</span>
                <a href="pengguna.php" class="nav-link">
                    <i class="fas fa-users-cog"></i>
                    <span>Pengguna</span>
                </a>
                <a href="anggota.php" class="nav-link">
                    <i class="fas fa-user-graduate"></i>
                    <span>Anggota</span>
                </a>

                <span class="nav-section-label">KOLEKSI</span>
                <a href="kategori.php" class="nav-link">
                    <i class="fas fa-tags"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php" class="nav-link">
                    <i class="fas fa-book"></i>
                    <span>Buku</span>
                </a>

                <span class="nav-section-label">TRANSAKSI</span>
                <a href="transaksi.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transaksi</span>
                </a>
                <a href="denda.php" class="nav-link">
                    <i class="fas fa-coins"></i>
                    <span>Denda</span>
                </a>
                <a href="laporan.php" class="nav-link active">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>

                <span class="nav-section-label">AKUN</span>
                <a href="profil.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profil Saya</span>
                </a>
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-globe"></i>
                    <span>Beranda</span>
                </a>
            </nav>

            <div class="sidebar-foot">
                <a href="logout.php" class="nav-link logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- MAIN AREA -->
        <div class="main-area">
            <!-- HEADER -->
            <header class="topbar">
                <div class="page-info">
                    <h1 class="page-title"><?= htmlspecialchars($page_title) ?></h1>
                    <div class="page-breadcrumb"><?= htmlspecialchars($page_sub) ?></div>
                </div>
                <div class="topbar-right">
                    <div class="topbar-date">
                        <i class="far fa-calendar-alt"></i> <?= date('d M Y') ?>
                    </div>
                    <div class="topbar-user">
                        <div class="topbar-avatar">
                            <?php if ($fotoPath): ?>
                            <img src="<?= $fotoPath ?>" alt="Foto">
                            <?php else: ?>
                            <?= htmlspecialchars($initials) ?>
                            <?php endif; ?>
                        </div>
                        <span class="topbar-username"><?= htmlspecialchars(getPenggunaName()) ?></span>
                    </div>
                    <a href="logout.php" class="btn-logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </header>

            <!-- CONTENT -->
            <main class="content">
                <!-- Page Header -->
                <div class="page-header">
                    <div>
                        <h1 class="page-header-title">Laporan Sistem</h1>
                        <p class="page-header-sub">Rekap data dan statistik perpustakaan</p>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon blue"><i class="fas fa-book"></i></div>
                        </div>
                        <div class="stat-label">Total Buku</div>
                        <div class="stat-value"><?= number_format($total_buku) ?></div>
                        <div class="stat-sub"><?= $buku_tersedia ?> unit tersedia</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon green"><i class="fas fa-users"></i></div>
                        </div>
                        <div class="stat-label">Anggota</div>
                        <div class="stat-value"><?= number_format($total_anggota) ?></div>
                        <div class="stat-sub">Terdaftar aktif</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon orange"><i class="fas fa-exchange-alt"></i></div>
                        </div>
                        <div class="stat-label">Transaksi</div>
                        <div class="stat-value"><?= number_format($total_pinjam) ?></div>
                        <div class="stat-sub"><?= $aktif_pinjam ?> sedang dipinjam</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <div class="stat-icon red"><i class="fas fa-coins"></i></div>
                        </div>
                        <div class="stat-label">Total Denda</div>
                        <div class="stat-value">Rp <?= number_format($total_denda,0,',','.') ?></div>
                        <div class="stat-sub">Belum lunas: Rp <?= number_format($denda_belum,0,',','.') ?></div>
                    </div>
                </div>

                <!-- Print control bar (screen only) -->
                <div class="print-bar-wrap no-print">
                    <div class="print-bar-label">
                        <i class="fas fa-file-pdf" style="color: var(--danger-500);"></i>
                        Pratinjau dokumen laporan — No. <strong><?= $no_laporan ?></strong>
                    </div>
                    <button onclick="window.print()" class="btn-primary">
                        <i class="fas fa-print"></i>
                        Cetak / Export PDF
                    </button>
                </div>

                <!-- REPORT DOCUMENT -->
                <div class="report-document">
                    <!-- Letterhead -->
                    <div class="rpt-letterhead">
                        <div class="rpt-org">
                            <div class="rpt-logo-mark">P</div>
                            <div class="rpt-org-name">Perpustakaan Digital</div>
                            <div class="rpt-org-sub">Sistem Manajemen Perpustakaan</div>
                        </div>
                        <div class="rpt-meta">
                            <div class="rpt-doc-number"><?= $no_laporan ?></div>
                            <div><strong>Tanggal Cetak</strong><br><?= $tgl_cetak ?></div>
                            <div><strong>Waktu</strong><br><?= $jam_cetak ?></div>
                            <div><strong>Dicetak oleh</strong><br>Administrator</div>
                        </div>
                    </div>

                    <!-- Title band -->
                    <div class="rpt-title-band">
                        <div class="rpt-title">Laporan Sistem Perpustakaan</div>
                        <div class="rpt-title-sub">Periode: <?= $tgl_cetak ?></div>
                    </div>

                    <!-- Stats -->
                    <div class="rpt-stats">
                        <div class="rpt-stat">
                            <div class="rpt-stat-bar"></div>
                            <div class="rpt-stat-label">Total Buku</div>
                            <div class="rpt-stat-val"><?= number_format($total_buku) ?></div>
                            <div class="rpt-stat-sub"><?= $buku_tersedia ?> unit tersedia</div>
                        </div>
                        <div class="rpt-stat">
                            <div class="rpt-stat-bar"></div>
                            <div class="rpt-stat-label">Anggota</div>
                            <div class="rpt-stat-val"><?= number_format($total_anggota) ?></div>
                            <div class="rpt-stat-sub">terdaftar aktif</div>
                        </div>
                        <div class="rpt-stat">
                            <div class="rpt-stat-bar"></div>
                            <div class="rpt-stat-label">Transaksi</div>
                            <div class="rpt-stat-val"><?= number_format($total_pinjam) ?></div>
                            <div class="rpt-stat-sub"><?= $aktif_pinjam ?> sedang dipinjam</div>
                        </div>
                        <div class="rpt-stat">
                            <div class="rpt-stat-bar"></div>
                            <div class="rpt-stat-label">Total Denda</div>
                            <div class="rpt-stat-val money">Rp <?= number_format($total_denda,0,',','.') ?></div>
                            <div class="rpt-stat-sub">belum lunas: Rp <?= number_format($denda_belum,0,',','.') ?></div>
                        </div>
                    </div>

                    <!-- Section 1: Transactions -->
                    <div class="rpt-section">
                        <div class="rpt-section-head">
                            <div class="rpt-section-num">1</div>
                            <div class="rpt-section-title">Laporan Transaksi Peminjaman</div>
                            <div class="rpt-section-count"><?= $trans_all ? $trans_all->num_rows : 0 ?> data</div>
                        </div>
                        <table class="rpt-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama Anggota</th>
                                    <th>NIS</th>
                                    <th>Kelas</th>
                                    <th>Judul Buku</th>
                                    <th>Tgl Pinjam</th>
                                    <th>Jatuh Tempo</th>
                                    <th>Tgl Kembali</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($trans_all && $trans_all->num_rows > 0): $n = 1; ?>
                                <?php while($r = $trans_all->fetch_assoc()):
                                    $late = $r['status_transaksi'] === 'Peminjaman' && strtotime($r['tgl_kembali_rencana']) < time();
                                    if ($r['status_transaksi'] === 'Pengembalian') { 
                                        $sc = 'kembali';  
                                        $sl = '<i class="fas fa-check-circle"></i> Kembali'; 
                                    } elseif ($late) { 
                                        $sc = 'terlambat'; 
                                        $sl = '<i class="fas fa-exclamation-triangle"></i> Terlambat'; 
                                    } else { 
                                        $sc = 'dipinjam';  
                                        $sl = '<i class="fas fa-book-reader"></i> Dipinjam'; 
                                    }
                                ?>
                                <tr>
                                    <td class="num"><?= $n++ ?></td>
                                    <td class="name"><?= htmlspecialchars($r['nama_anggota']) ?></td>
                                    <td class="mono"><?= htmlspecialchars($r['nis']) ?></td>
                                    <td><?= htmlspecialchars($r['kelas']) ?></td>
                                    <td class="book"><?= htmlspecialchars($r['judul_buku']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($r['tgl_pinjam'])) ?></td>
                                    <td><?= date('d/m/Y', strtotime($r['tgl_kembali_rencana'])) ?></td>
                                    <td><?= $r['tgl_kembali_aktual'] ? date('d/m/Y', strtotime($r['tgl_kembali_aktual'])) : '—' ?>
                                    </td>
                                    <td><span class="rpt-badge <?= $sc ?>"><?= $sl ?></span></td>
                                </tr>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="9" class="rpt-empty">Belum ada data transaksi</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Section 2: Fines -->
                    <div class="rpt-section">
                        <div class="rpt-section-head">
                            <div class="rpt-section-num">2</div>
                            <div class="rpt-section-title">Laporan Denda Keterlambatan</div>
                            <div class="rpt-section-count"><?= $denda_all ? $denda_all->num_rows : 0 ?> data</div>
                        </div>
                        <table class="rpt-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama Anggota</th>
                                    <th>Judul Buku</th>
                                    <th>Keterlambatan</th>
                                    <th>Total Denda</th>
                                    <th>Status Bayar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($denda_all && $denda_all->num_rows > 0): $n = 1; ?>
                                <?php while($r = $denda_all->fetch_assoc()): ?>
                                <tr>
                                    <td class="num"><?= $n++ ?></td>
                                    <td class="name"><?= htmlspecialchars($r['nama_anggota']) ?></td>
                                    <td class="book"><?= htmlspecialchars($r['judul_buku']) ?></td>
                                    <td><?= $r['jumlah_hari'] ?> hari</td>
                                    <td class="money-cell">Rp <?= number_format($r['total_denda'],0,',','.') ?></td>
                                    <td>
                                        <?php if ($r['status_bayar'] === 'sudah'): ?>
                                        <span class="rpt-badge lunas"><i class="fas fa-check"></i> Lunas</span>
                                        <?php else: ?>
                                        <span class="rpt-badge belum"><i class="fas fa-times"></i> Belum</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="6" class="rpt-empty">Belum ada data denda</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Footer / Signature -->
                    <div class="rpt-footer">
                        <div class="rpt-footer-left">
                            <i class="fas fa-file-alt" style="color: var(--primary-500);"></i>
                            Dokumen ini digenerate otomatis oleh sistem.<br>
                            No. Dokumen: <strong><?= $no_laporan ?></strong> &nbsp;|&nbsp; <?= $tgl_cetak ?>,
                            <?= $jam_cetak ?>
                        </div>
                        <div class="rpt-signature">
                            <div class="rpt-signature-line"></div>
                            <div>Administrator</div>
                            <div class="rpt-signature-title">Penanggung Jawab</div>
                        </div>
                    </div>
                </div><!-- /report-document -->
            </main>
        </div>
    </div>

    <script>
    // Prevent form resubmission
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
    <script src="../assets/js/script.js"></script>
</body>

</html>